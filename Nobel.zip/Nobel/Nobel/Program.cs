﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Nobel
{
    class Nobel
    {
        public int evszam;
        public string tipus, kernev, veznev;
        public Nobel(string egysor)
        {
            string[] darabok = egysor.Split(';');
            evszam = int.Parse(darabok[0]);
            tipus = darabok[1];
            kernev = darabok[2];
            veznev = darabok[3];

        }

    }
    class Program
    {
        
        
        static void Main(string[] args)
        {
            string[] beolvas = File.ReadAllLines(@"D:\forras\nobel.csv");
            Nobel[] nobelek = new Nobel[beolvas.Length];
            for (int i = 1; i < nobelek.Length; i++)
            {
                nobelek[i] = new Nobel(beolvas[i]);
            }
            for (int i = 1; i < nobelek.Length; i++)
            {

                if (nobelek[i].kernev=="Arthur B." && nobelek[i].veznev=="McDonald")
                {
                    Console.WriteLine("3.feladat: {0}",nobelek[i].tipus);
                }
               
            }
            //4. feladat
            for (int i = 1; i < nobelek.Length; i++)
            {
                if (nobelek[i].evszam==2017 && nobelek[i].tipus=="irodalmi")
                {
                    Console.WriteLine("4.feladat: {0} {1}",nobelek[i].kernev,nobelek[i].veznev);
                }
            }
            //5.feladat
            Console.WriteLine("5.feladat:");
            for (int i = 1; i < nobelek.Length; i++)
            {
                
                if (string.IsNullOrEmpty(nobelek[i].veznev)==true && nobelek[i].evszam > 1990)
                {
                    Console.WriteLine("\t{0}: {1}",nobelek[i].evszam,nobelek[i].kernev);
                }
             
                           }
            //6.feladat
            Console.WriteLine("6.feladat:");
            for (int i = 1; i < nobelek.Length; i++)
            {
                if (nobelek[i].veznev.Contains("Curie"))
                {
                    Console.WriteLine("{0}: {1} {2}({3})",nobelek[i].evszam,nobelek[i].kernev,nobelek[i].veznev,nobelek[i].tipus);
                }
            }
            Console.ReadKey();
        }
    }
}
